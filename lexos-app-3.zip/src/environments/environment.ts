// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'lexos-app-tareas',
    appId: '1:890615602147:web:ca2f1bef0b9cf51eb9ded6',
    storageBucket: 'lexos-app-tareas.appspot.com',
    locationId: 'southamerica-east1',
    apiKey: 'AIzaSyBUzgh3KcZBZ8pleEnuxQwY6H0Vxr0TJcc',
    authDomain: 'lexos-app-tareas.firebaseapp.com',
    messagingSenderId: '890615602147',
    measurementId: 'G-L9M9ZDK976',
  },
  production: false
};

/*
 * In development mode, to ignore zone related error stack frames such as
 * `zone.run`, `zoneDelegate.invokeTask` for easier debugging, you can
 * import the following file, but please comment it out in production mode
 * because it will have performance impact when throw error
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
