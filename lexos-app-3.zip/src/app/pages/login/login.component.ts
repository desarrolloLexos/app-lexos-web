import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subject, Subscription, filter, takeUntil, tap, timer, map } from 'rxjs';
import { isLoading, stopLoading } from 'app/store/actions';

import { AppSettings } from '../../app.settings';
import { AppState } from 'app/store/app.reducers';
import { AuthService } from '../../services/auth.service';
import { ControlPosition } from '@agm/core';
import { Router } from '@angular/router';
import { Settings } from '../../app.settings.model';
import { Store } from '@ngrx/store';
import Swal from 'sweetalert2';
import { Usuario } from '../../models/usuario.model';
import { emailValidator } from '../../theme/utils/app-validators';
import { setUser } from '../../store/actions/auth.actions';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styles: ['input { font-size: 12pt; vertical-align: middle; line-height: 30px; }',
          ' .mat-icon { vertical-align: middle; }',
          ' .mat-error { text-align: right;}',
          ' button .fa-sync { float: left; margin-top: 12px; }']
})
export class LoginComponent implements OnInit, OnDestroy {
  public form:FormGroup;
  public settings: Settings;
  public hide = true;
  public cargando: boolean = true;
  private stop$ = new Subject<void>();

  constructor(
            public appSettings:AppSettings,
            public fb: FormBuilder,
            public router:Router,
            public authService: AuthService,
            public store: Store<AppState>){
    this.settings = this.appSettings.settings;


   this.store.select('user')
              .pipe(
                    filter( ({user}) => user !== null),
                    tap( () => {
                      if(this.authService.loadInitAuthListener){
                        this.cargando = true;
                      }
                    }),
                    takeUntil(this.stop$))
              .subscribe( () => {
                this.router.navigate(['/'])
              });
  }

  ngOnInit(): void {
    // this.authService.initAuthListener();

    this.form = this.fb.group({
      'email': ['', Validators.compose([Validators.required, emailValidator])],
      'password': ['', Validators.compose([Validators.required, Validators.minLength(6)])],
      'rememberMe': false
    });

    // Creamos la suscripción a isLoading y le pasamos la referencia a variable local
    this.store.select('ui').pipe(takeUntil(this.stop$) )
                           .subscribe( ui => { this.cargando = ui.isLoading; });
  }

  ngOnDestroy(): void {
    stop();
  }

  ngAfterViewInit(){
    setTimeout(() => {
      this.settings.loadingSpinner = false;
    });
  }

  loginUsuario(){
    if(this.form.invalid){ return; }

    this.store.dispatch( isLoading());

    const {email, password} = this.form.value;
    this.authService.login(email, password)
    .then( credenciales => {
        console.log('Credenciales: ', credenciales);
        this.authService.cargarUsuario(credenciales.user);
        this.store.dispatch( stopLoading());
        
        this.router.navigate(['/']);
    })
    .catch( err => {
      this.store.dispatch( stopLoading());

      Swal.fire({
      icon: 'error',
      title: 'Oops...',
      text: err.message,
      // footer: '<a href="">Why do I have this issue?</a>'
    })});
  }

  stop() {
    this.stop$.next();
    this.stop$.complete();
  }
}
