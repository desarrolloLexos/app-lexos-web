import * as actions from '../../../store/actions';

import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';

import { AppState } from 'app/store/app.reducers';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { SelectionModel } from '@angular/cdk/collections';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { TareaOT } from 'app/models/tarea-ot.model';
import { TareasService } from '../../../services/tareas.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tareas-ot',
  templateUrl: './tareas-ot.component.html',
  styleUrls: ['./tareas-ot.component.scss'],
})
export class TareasOtComponent implements OnInit, OnDestroy {
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild('backToTop') backToTop:any;
  @ViewChild('table', {read: ElementRef}) table: ElementRef;
  @ViewChild('tableHeader', {read: ElementRef}) tableHeader: ElementRef;
  selection = new SelectionModel<TareaOT>(true, []);
  public displayedColumns =[
           'select',    // Checkbox de selección
           'wo_folio',
           'id_status_work_order',
           'code',
           'items_log_description',
           'is_offline',
           'description',
           'trigger_description',
           'parent_description',
           'items_log_types_description',
           'groups_1_description',
           'groups_2_description',
           'completed_percentage',
           'duration',
           'real_duration',
           'tasks_log_task_type_main',
           'num_iterations',
           'cal_date_maintenance',
           'date_maintenance',
           'initial_date',
           'final_date',
           'creation_date',
           'wo_final_date',
           'stop_assets',
           'stop_assets_sec',
           'real_stop_assets_sec',
           'resources_hours',
           'resources_inventory',
           'personnel_description',
           'id_parent',
           'requested_by',
           'priorities_description',
           'task_note',
           'note',
           'event_date',
           'rating',
           'id_request',
           'work_orders_status_custom_description'
  ];
  private stop$ = new Subject<void>();
  public tareas: TareaOT[] = [];
  public loading: boolean = false;
  public error: any;
  public dataSource: any;
  constructor(private store: Store<AppState>,
              private tareaService: TareasService,
              private route: Router) {

      this.store.dispatch(actions.getTareasOT());
      this.store.dispatch(actions.setPages({page: {showTareasOT: true}}));
  }

  ngOnInit(): void {

    this.store.select('tareas').subscribe( ({tareas, loading, error}) => {
      console.log('Tareas disponibles en el STORE: ', tareas.length);
      this.tareas = tareas;
      this.loading = loading;
      this.error = error;
      this.dataSource = new MatTableDataSource<TareaOT>(this.tareas);
    });

  }

  ngOnDestroy(): void {
    stop();
  }

  stop() {
    this.stop$.next();
    this.stop$.complete();
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.tareas.length;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    if (this.isAllSelected()) {
      this.selection.clear();
      return;
    }

    this.selection.select(...this.tareas);
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: TareaOT): string {
    if (!row) {
      return `${this.isAllSelected() ? 'deselect' : 'select'} all`;
    }
    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${row.wo_folio + 1}`;
  }

  /**
   * Método que ejecuta el Scroll Infinito en la tabla de Órdenes de Trabajo.
   */
  onScroll() {
      if(!this.loading){    // Si el loading esta en true, es porque ya hay otro dispatch pendiente.
        this.store.dispatch( actions.getTareasOTScroll() );            // Obtiene las 50 siguientes OT.
      }
  }

  /**
   * Filtra datos en la tabla cargada del store.
   * @param filterValue Palabra a buscar en la tabla
   */
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  /**
   * Mueve el scroll al principio de la tabla
   */
  public scrollToTop(): void {
    console.log('Preparando ScrollToTop()');
    this.table.nativeElement.scrollIntoView();
    this.tableHeader.nativeElement.scrollIntoView();
  }

  public getRecord(tarea:TareaOT): void {
    this.route.navigate(['/','task','details'], { queryParams: { id: tarea.id } });
  }
}
