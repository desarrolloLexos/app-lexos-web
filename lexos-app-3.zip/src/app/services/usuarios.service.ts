import * as actions from '../store/actions';

import { Firestore, Unsubscribe, addDoc, collection, deleteDoc, doc, onSnapshot, orderBy, query, getDocs } from '@angular/fire/firestore';

import { AppState } from '../store/app.reducers';
import { AuthService } from './auth.service';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { Usuario, UsuarioConverter } from '../models/usuario.model';

@Injectable({
  providedIn: 'root'
})
export class UsuariosService {

  unsubscribe!: Unsubscribe;

  constructor(
    private firestore: Firestore,
    private authService: AuthService,
    private store: Store<AppState>) {
  }

  async getUsuarios(){
    const docRef = query(collection(this.firestore, "usuarios")
                   .withConverter(UsuarioConverter));
    const docSnap = await getDocs(docRef);
    const usuarios: Usuario[] = [];
    docSnap.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      usuarios.push(doc.data());
    });
    return usuarios;
  }

  unsubscribeUsuariosListener(){
    if(this.unsubscribe) this.unsubscribe();
  }

  borrarUsuario(uid: string){
    return deleteDoc(doc(this.firestore, "usuarios", uid));
  }

  // getUserById(id: string){
  //   return onSnapshot(doc(this.firestore, "usuarios", fuser.uid)
  //   .withConverter(UsuarioConverter),
  //       (doc) => {
  //       // Respond to data
  //       if(doc.exists()){
  //       const usuario = doc.data();
  //       this._user = usuario;
  //       this.store.dispatch( actions.setUser({user: usuario}) );
  //       }else{
  //       console.log("No such document!");
  //       this._user = null;
  //       this.store.dispatch( actions.unSetUser());
  //       }

  //       });
  // }
}
