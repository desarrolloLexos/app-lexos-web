import * as actions from '../store/actions';

import {
         Auth,
         authState,
         createUserWithEmailAndPassword,
         signInWithEmailAndPassword,
         signOut,
         User
} from '@angular/fire/auth';
import { Firestore, Unsubscribe, collection, doc, getDocs, onSnapshot, query, where } from '@angular/fire/firestore';
import { Usuario, UsuarioConverter } from '../models/usuario.model';

import { AppState } from '../store/app.reducers';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { map } from 'rxjs';
import { setDoc } from 'firebase/firestore';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  unsubscribe!: Unsubscribe;

  private _user: Usuario | null = null;
  private _loadInitAuthListener: boolean = false;
  private _userID: string;

  constructor(public auth: Auth,
              public firestore: Firestore,
              private store: Store<AppState>) {
   }

  get user(){
    return this._user;
  }

  get userID(){
    return this._userID;
  }

  /**
   * Indica si ya se cargó el initAuthListener.
   * Será usado por LOGIN para detectar usuarios previamente identificados y que han mantenido la sesión.
   */
  get loadInitAuthListener(){
    return this._loadInitAuthListener;
  }

  initAuthListener(){
    return authState(this.auth).subscribe( async fuser => {
      this._loadInitAuthListener = true;
      if(fuser){  // fuser tiene información parcial del usuario pero no el nombre.        
          this.cargarUsuario(fuser);
      }
      // else{
      //   console.log('cancelando subscrición user...');
      //   if(this.unsubscribe) this.unsubscribe(); // Stop listening to changes
      //   this._user = null;
      //   this.store.dispatch( actions.unSetUser());
      //   // this.store.dispatch( ingresoEgresoActions.unSetItems());
      // }

    });
  }

  async cargarUsuario(fuser: User) {
    // Por lo que debemos consultar a firestore por el documento para obtener el nombre:
    const q = query(collection(this.firestore, "usuarios").withConverter(UsuarioConverter),
      where("uid", "==", fuser.uid));
    const querySnapshot = await getDocs(q);
    if (querySnapshot) {
      querySnapshot.forEach((doc) => {
        // doc.data() is never undefined for query doc snapshots
        console.log(doc.id, " => ", doc.data());
        const usuario: Usuario = doc.data();
        this._user = usuario;
        this._userID = doc.id;
        this.store.dispatch(actions.setUser({ user: usuario }))
      });
    } else {
      console.log("Usuario no encontrado!");
      this._user = null;
      this.store.dispatch(actions.unSetUser());
    }
  }

  crearUsuario(usuario: Usuario, password: string): Promise<any> {
    return createUserWithEmailAndPassword(this.auth, usuario.email, password)
    .then(  async ({ user }) => {
        // Creación de nueva instancia de usuario
        // const newUser = new Usuario(user.uid, nombre, email);
        // const userRef = collection(this.firestore, `usuarios`);
        usuario.uid = user.uid;
        // Postear la información a Firebase
        // return addDoc( userRef, {...newUser})
         // Add a new document in collection "cities"
         return await setDoc(doc(this.firestore, "usuarios"), {...usuario});
      }
    )
  }


  login(email: string, password: string){
    return signInWithEmailAndPassword(this.auth, email, password);
  }

  logout(){
    return signOut(this.auth);
  }

  isAuth(){
    return authState(this.auth).pipe(
      map(fUser => (fUser !== null))
    )
  }


}
