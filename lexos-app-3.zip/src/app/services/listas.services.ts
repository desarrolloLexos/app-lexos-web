import { Firestore, collection, getDocs, orderBy, query } from '@angular/fire/firestore';

import { Injectable } from '@angular/core';
import { TipoFallaConverter } from '../models/tipo-falla.model';
import { CausaFallaConverter } from '../models/causa-falla.model';
import { MetodoDeteccionConverter } from '../models/metodo-deteccion.model';

@Injectable({
  providedIn: 'root'
})
export class ListasService {

  constructor(private firestore: Firestore) { }

  async getListaTipoFalla() {
    const docRef = query(collection(this.firestore, "tipo_falla")
                    .withConverter(TipoFallaConverter),
                    orderBy("description", "asc"));
    const docSnap = await getDocs(docRef);
    return docSnap.docs.map( (o) => o.data());
  }

  async getListaCausaFalla(){
    const docRef = query(collection(this.firestore, "lista_causas_fallas")
                   .withConverter(CausaFallaConverter),
                   orderBy("description", "asc"));
    const docSnap = await getDocs(docRef);
    return docSnap.docs.map( (o) => o.data());
  }

  async getListaMetodoDeteccion(){
    const docRef = query(collection(this.firestore, "lista_metodo_deteccion")
                   .withConverter(MetodoDeteccionConverter),
                   orderBy("description", "asc"));
    const docSnap = await getDocs(docRef);
    return docSnap.docs.map( (o) => o.data());
  }


}
