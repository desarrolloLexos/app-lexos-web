import { Storage, deleteObject, getDownloadURL, listAll, ref, uploadBytes, uploadBytesResumable } from '@angular/fire/storage';

import { FileUpload } from '../models/file-upload.model';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FileUploadService {

  urlGenerated: string;

  constructor(private storage: Storage) { }

  /**
   * Coloca el archivo en el Firestore Storage
   * @param path Ruta en donde estará el archivo.
   * @param fileUpload Objeto con archivo y nombre especificado.
   * @returns
   */
  public pushFileToStorage(
    path: string, 
    fileUpload: FileUpload) {
    const filePath = `${path}/${fileUpload.file.name}`;

    if(fileUpload){
      const imgRef = ref(this.storage, filePath);
      const uploadTask = uploadBytesResumable( imgRef, fileUpload.file);

      // Listen for state changes, errors, and completion of the upload.
      return uploadTask.on('state_changed',
        (snapshot) => {
          // Get task progress, including the number of bytes uploaded and the total number of bytes to be uploaded
          const progress = (snapshot.bytesTransferred / snapshot.totalBytes) * 100;
          console.log('Upload is ' + progress + '% done');
          switch (snapshot.state) {
            case 'paused':
              console.log('Upload is paused');
              break;
            case 'running':
              console.log('Upload is running');
              break;
          }
        },
        (error) => {
          // A full list of error codes is available at
          // https://firebase.google.com/docs/storage/web/handle-errors
          switch (error.code) {
            case 'storage/unauthorized':
              // User doesn't have permission to access the object
              console.error(error);
              break;
            case 'storage/canceled':
              // User canceled the upload
              console.error(error);
              break;
      
            // ...
      
            case 'storage/unknown':
              // Unknown error occurred, inspect error.serverResponse
              console.error(error);
              break;
          }
        },
        () => {
          // Upload completed successfully, now we can get the download URL
          getDownloadURL(uploadTask.snapshot.ref).then((downloadURL) => {
            console.log('File available at', downloadURL);
            return downloadURL;
          });
        }
      );
    }   
  }


  public getImages(path: string){
    const imgRef = ref(this.storage, path);
    return listAll(imgRef);
  }


  public deleteFile(path: string, fileUpload: FileUpload): void {
    // Create a reference to the file to delete
    const desertRef = ref(this.storage, `${path}/${fileUpload.name}`);

    // Delete the file
    deleteObject(desertRef).then(() => {
      // File deleted successfully
      console.log('Archivo eliminado correctamente.');
    }).catch((error) => {
      // Uh-oh, an error occurred!
      console.error('No se pudo eliminar el archivo. ', error);
    });
  }
}
