import { createReducer, on } from '@ngrx/store';
import { isLoading, stopLoading } from '../actions';

export interface UIState {
    isLoading: boolean;
}

export const initialUIState: UIState = {
   isLoading: false,
}

export const uiReducer = createReducer(
  initialUIState,
  on(isLoading,   state => ({ ...state, isLoading: true })),
  on(stopLoading, state => ({ ...state, isLoading: false})),

);
