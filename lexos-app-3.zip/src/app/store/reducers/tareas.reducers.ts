import * as actions from './../actions';

import { createReducer, on } from '@ngrx/store';

import { TareaOT } from '../../models/tarea-ot.model';

export interface TareasOTState {
  tareas: TareaOT[],
  loaded : boolean,
  loading: boolean,
  error  : any,
  tareaOT : TareaOT;
}

export const initialStateTareasOT: TareasOTState = {
  tareas: [],
  loaded : false,
  loading: false,
  error  : null,
  tareaOT : null
}

export const tareasOTReducer = createReducer(
  initialStateTareasOT,

  // Reducers relacionados a la carga inicial de las Ordenes de Trabajo.
  on(actions.getTareasOT, state => ({...state, loading: true})),
  on(actions.getTareasOTSuccess, (state, { tareasOT }) => ({...state, loading: false, loaded: true, tareas: [...tareasOT]})),
  on(actions.getTareasOTError, (state, { payload }) => ({   ...state, loading: false,  loaded: false,
    error: {
      url: payload.url,
      name: payload.name,
      message: payload.message
    }
  })),

  // Reducers relacionados a la carga de scroll infinito en listado de Ordenes de Trabajo.
  on(actions.getTareasOTScroll, state => ({ ...state, loading: true})),
  on(actions.getTareasOTScrollSuccess, (state, { tareasOT }) => ({...state, loading: false,  loaded: true,
    tareas: state.tareas.concat([ ...tareasOT])     // para no perder el listado anterior, se contatena
  })),
  on(actions.getTareasOTScrollError, (state, { payload }) => ({   ...state, loading: false,  loaded: false,
    error: {
      url: payload.url,
      name: payload.name,
      message: payload.message
    }
  })),

   // Reducers relacionados a la creación de una tarea en el Firebase Cloud Firestore.
   on(actions.crearTareaOT, (state, {tareaOT}) => ({ ...state, tareaOT: tareaOT})),
   on(actions.crearTareaOTSuccess, (state, { tareaOT }) => ({...state, loading: false,  loaded: true,
      tareaOT: tareaOT
   })),
   on(actions.crearTareaOTError, (state, { payload }) => ({   ...state, loading: false,  loaded: false,
     error: {
       url: payload.url,
       name: payload.name,
       message: payload.message
     }
   })),

  on( actions.UnSetTareasOT, (state) => ({ ...state, tareas: [] })),

);
