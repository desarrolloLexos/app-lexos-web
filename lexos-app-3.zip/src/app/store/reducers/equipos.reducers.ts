import { cargarEquipos, cargarEquiposError, cargarEquiposSuccess } from '../actions';
import { createReducer, on } from '@ngrx/store';

import { Equipo } from 'app/models/equipo.model';

export interface EquiposState {
    uid        : string,
    codigolocal: string,
    equipos?   : Equipo[] | null,
    loaded : boolean,
    loading: boolean,
    error  : any,
}

export const EquiposInitialState: EquiposState = {
    uid      : null,
    codigolocal: null,
    equipos  : [],
    loaded : false,
    loading: false,
    error  : null,
    // user   : [],
}

export const equiposReducer = createReducer(
  EquiposInitialState,
  on(cargarEquipos, (state, {uid, codigolocal}) => ({
    ...state,
    loading: true,
    uid: uid,
    codigolocal: codigolocal
  })),

  on(cargarEquiposSuccess, (state, { equipos }) => ({
    ...state,
    loading: false,
    loaded: true,
    equipos: [...equipos],
  })),

  on(cargarEquiposError, (state, { payload }) => ({
    ...state,
    loading: false,
    loaded: false,
    error: {
      url: payload.url,
      name: payload.name,
      message: payload.message
    }
  }))
);
