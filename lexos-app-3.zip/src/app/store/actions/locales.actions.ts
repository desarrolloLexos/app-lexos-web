import { createAction, props } from '@ngrx/store';

import { Local } from 'app/models/local.model';

export const cargarLocales = createAction(
        '[Locales] cargar Locales',
        props<{uid: string}>());

export const cargarLocalesSuccess = createAction(
       '[Locales] cargar Locales Success',
        props<{locales: Local[]}>());

export const cargarLocalesError = createAction(
       '[Locales] cargar Locales Error',
        props<{ payload: any}>());
