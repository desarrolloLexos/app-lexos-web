// Encargado de exportar todas las acciones en donde quiera que se necesite.
export * from './usuarios.actions';
export * from './usuario.actions';
export * from './auth.actions';
export * from './ui.actions';
export * from './tareas.actions';
export * from './tarea.actions';
export * from './contador.actions';
export * from './pages.actions';
export * from './cliente.actions';
export * from './clientes.actions';
export * from './equipos.actions';
export * from './locales.actions';
export * from './folio.actions';
export * from './listas.actions';
