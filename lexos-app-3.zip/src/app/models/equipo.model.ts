import { DocumentData, QueryDocumentSnapshot, SnapshotOptions } from "@angular/fire/firestore";

export class Equipo {

  /* Forma corta de crear un modelo en typescript */
  constructor(
      public codigo: string,
      public nombre: string,
      public fabricante: string,
      public modelo: string,
      public serial: string,
      public otro: string,
      public tipo: string,
      public codigolocal: string,
  ){}
}

/* Tipo que permite usar desestructuración de objeto en clase Equipo */
export type EquipoType = {
      codigo: string,
      nombre: string,
      fabricante: string,
      modelo: string,
      serial: string,
      otro: string,
      tipo: string,
      codigolocal: string,
}

  
// Firestore data converter
export const EquipoConverter = {
  toFirestore: (equipo: Equipo) => {
      return {
        "codigo": equipo.codigo,
        "nombre": equipo.nombre,
        "fabricante": equipo.fabricante,
        "modelo": equipo.modelo,
        "serial": equipo.serial,
        "otro": equipo.otro,
        "tipo": equipo.tipo,
        "codigolocal": equipo.codigolocal,
        
          };
  },
  fromFirestore: (snapshot: QueryDocumentSnapshot<DocumentData>,
                  options: SnapshotOptions) => {
      const data = snapshot.data(options);
      return new Equipo(
        data['codigo'],
        data['nombre'],
        data['fabricante'],
        data['modelo'],
        data['serial'],
        data['otro'],
        data['tipo'],
        data['codigolocal'],               
        );
  }
};
