export const environment = {
  firebase: {
    projectId: 'lexos-app-tareas',
    appId: '1:890615602147:web:ca2f1bef0b9cf51eb9ded6',
    storageBucket: 'lexos-app-tareas.appspot.com',
    locationId: 'southamerica-east1',
    apiKey: 'AIzaSyBUzgh3KcZBZ8pleEnuxQwY6H0Vxr0TJcc',
    authDomain: 'lexos-app-tareas.firebaseapp.com',
    messagingSenderId: '890615602147',
    measurementId: 'G-L9M9ZDK976',
  },
  production: true
};
