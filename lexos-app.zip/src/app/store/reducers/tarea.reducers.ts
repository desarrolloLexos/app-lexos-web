import { cargarTareaOT, cargarTareaOTError, cargarTareaOTSuccess } from '../actions';
import { createReducer, on } from '@ngrx/store';

import { TareaOT } from 'src/app/models/tarea-ot.model';

export interface TareaOTState {
    uid?     : string | null,
    tareaOT? : TareaOT | null,
    loaded   : boolean,
    loading  : boolean,
    error    : any,
}

export const tareaOTInitialState: TareaOTState = {
    uid     : null,
    tareaOT : null,
    loaded  : false,
    loading : false,
    error   : null,
}

export const TareaOTReducer = createReducer(
    tareaOTInitialState,
  on(cargarTareaOT, (state, { id }) => ({
    ...state,
    loading: true,
    id:  id
  })),

  on(cargarTareaOTSuccess, (state, { tareaOT }) => ({
    ...state,
    loading: false,
    loaded: true,
    tareaOT: {...tareaOT},
  })),

  on(cargarTareaOTError, (state, { payload }) => ({
    ...state,
    loading: false,
    loaded: false,
    error: {
      url: payload.url,
      name: payload.name,
      message: payload.message
    }
  }))
);
