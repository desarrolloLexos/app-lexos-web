import { cargarEquipos, cargarEquiposError, cargarEquiposSuccess } from '../actions';
import { createReducer, on } from '@ngrx/store';

import { Equipo } from 'src/app/models/equipo.model';

export interface EquiposState {
    uid: string,
    equipos?   : Equipo[] | null,
    loaded : boolean,
    loading: boolean,
    error  : any,
}

export const EquiposInitialState: EquiposState = {
    uid: null,
    equipos  : [],
    loaded : false,
    loading: false,
    error  : null,
    // user   : [],
}

export const equiposReducer = createReducer(
  EquiposInitialState,
  on(cargarEquipos, (state, {uid}) => ({
    ...state,
    loading: true,
    uid: uid
  })),

  on(cargarEquiposSuccess, (state, { equipos }) => ({
    ...state,
    loading: false,
    loaded: true,
    equipos: [...equipos],
  })),

  on(cargarEquiposError, (state, { payload }) => ({
    ...state,
    loading: false,
    loaded: false,
    error: {
      url: payload.url,
      name: payload.name,
      message: payload.message
    }
  }))
);
