import * as actions from 'src/app/store/actions';
import { createReducer, on } from '@ngrx/store';

import { TipoFalla } from 'src/app/models/tipo-falla.model';
import { MetodoDeteccion } from 'src/app/models/metodo-deteccion.model';
import { CausaFalla } from 'src/app/models/causa-falla.model';

export interface TipoFallasState {
    tipoFallas  : TipoFalla[],
    loaded : boolean,
    loading: boolean,
    error  : any,
}

export interface CausaFallasState {
    causaFallas  : CausaFalla[],
    loaded : boolean,
    loading: boolean,
    error  : any,
}

export interface MetodosDeteccionState {
    metodosDeteccion  : MetodoDeteccion[],
    loaded : boolean,
    loading: boolean,
    error  : any,
}
export const tipoFallasInitialState: TipoFallasState = {
    tipoFallas  : [],
    loaded : false,
    loading: false,
    error  : null,
}

export const causaFallasInitialState: CausaFallasState = {
    causaFallas  : [],
    loaded : false,
    loading: false,
    error  : null,
}

export const metodosDeteccionInitialState: MetodosDeteccionState = {
    metodosDeteccion  : [],
    loaded : false,
    loading: false,
    error  : null,
}

export const tipoFallasReducer = createReducer(
  tipoFallasInitialState,
  on(actions.cargarTipoFalla, state => ({ ...state, loading: true})),

  on(actions.cargarTipoFallaSuccess, (state, { tipoFallas }) => ({
    ...state,
    loading: false,
    loaded: true,
    tipoFallas: [ ...tipoFallas]
  })),

  on(actions.cargarTipoFallaError, (state, { payload }) => ({
    ...state,
    loading: false,
    loaded: false,
    error: {
      url: payload.url,
      name: payload.name,
      message: payload.message
    }
  }))
);

export const causaFallasReducer = createReducer(
  causaFallasInitialState,
  on(actions.cargarCausaFalla, state => ({ ...state, loading: true})),

  on(actions.cargarCausaFallaSuccess, (state, { causaFallas }) => ({
    ...state,
    loading: false,
    loaded: true,
    causaFallas: [ ...causaFallas]
  })),

  on(actions.cargarCausaFallaError, (state, { payload }) => ({
    ...state,
    loading: false,
    loaded: false,
    error: {
      url: payload.url,
      name: payload.name,
      message: payload.message
    }
  }))
);

export const metodosDeteccionReducer = createReducer(
  metodosDeteccionInitialState,
  on(actions.cargarMetodoDeteccion, state => ({ ...state, loading: true})),

  on(actions.cargarMetodoDeteccionSuccess, (state, { metodosDeteccion }) => ({
    ...state,
    loading: false,
    loaded: true,
    metodosDeteccion: [ ...metodosDeteccion]
  })),

  on(actions.cargarMetodoDeteccionError, (state, { payload }) => ({
    ...state,
    loading: false,
    loaded: false,
    error: {
      url: payload.url,
      name: payload.name,
      message: payload.message
    }
  }))
);