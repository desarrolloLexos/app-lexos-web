import { createAction, props } from '@ngrx/store';

import { TareaOT } from 'src/app/models/tarea-ot.model';

export const cargarTareaOT = createAction(
        '[TareaOT] cargar TareaOT',
        props<{id: string}>());

export const cargarTareaOTSuccess = createAction(
       '[TareaOT] cargar TareaOT Success',
        props<{tareaOT: TareaOT}>());

export const cargarTareaOTError = createAction(
       '[TareaOT] cargar TareaOT Error',
        props<{ payload: any}>());
