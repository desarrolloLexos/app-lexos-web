import { createAction, props } from "@ngrx/store";
import { CausaFalla } from "src/app/models/causa-falla.model";
import { MetodoDeteccion } from "src/app/models/metodo-deteccion.model";
import { TipoFalla } from "src/app/models/tipo-falla.model";

export const cargarTipoFalla = createAction("[TipoFalla] cargar TipoFalla");
export const cargarTipoFallaSuccess = createAction(
  "[TipoFalla] cargar TipoFalla Success",
  props<{ tipoFallas: TipoFalla[] }>()
);
export const cargarTipoFallaError = createAction(
  "[TipoFalla] cargar TipoFalla Error",
  props<{ payload: any }>()
);

export const cargarCausaFalla = createAction("[CausaFalla] cargar CausaFalla");
export const cargarCausaFallaSuccess = createAction(
  "[CausaFalla] cargar CausaFalla Success",
  props<{ causaFallas: CausaFalla[] }>()
);
export const cargarCausaFallaError = createAction(
  "[CausaFalla] cargar CausaFalla Error",
  props<{ payload: any }>()
);

export const cargarMetodoDeteccion = createAction(
  "[MetodoDeteccion] cargar MetodoDeteccion"
);
export const cargarMetodoDeteccionSuccess = createAction(
  "[MetodoDeteccion] cargar MetodoDeteccion Success",
  props<{ metodosDeteccion: MetodoDeteccion[] }>()
);
export const cargarMetodoDeteccionError = createAction(
  "[MetodoDeteccion] cargar MetodoDeteccion Error",
  props<{ payload: any }>()
);
