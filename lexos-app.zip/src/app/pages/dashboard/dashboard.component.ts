import * as actions from 'src/app/store/actions';

import { Component, OnInit } from '@angular/core';

import { AppState } from '../../store/app.reducers';
import { Store } from '@ngrx/store';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  constructor(private store: Store<AppState>) {
    this.store.dispatch(actions.setPages({page: {showTareasOT: false}}));
    this.store.dispatch( actions.cargarUsuarios());
  }

  ngOnInit() {
  }

}
