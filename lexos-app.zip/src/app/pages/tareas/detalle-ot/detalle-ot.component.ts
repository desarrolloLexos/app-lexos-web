import * as moment from "moment";
import * as actions from "src/app/store/actions";

import { Component, OnInit, OnDestroy } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  Validators,
} from "@angular/forms";
import { filter, map, startWith, take, skip } from "rxjs/operators";
import { Observable, Subject, takeUntil, interval } from 'rxjs';
import { ThemePalette } from "@angular/material/core";
import { Local } from "src/app/models/local.model";
import { Cliente } from "src/app/models/cliente.model";
import { Equipo } from "src/app/models/equipo.model";
import { select, Store } from "@ngrx/store";
import { AppState } from "src/app/store/app.reducers";
import { NgxMatComboboxFilterOptionsFn } from "ngx-mat-combobox";
import { AuthService } from "src/app/services/auth.service";
import { Usuario } from "src/app/models/usuario.model";
import { TareaOT } from '../../../models/tarea-ot.model';
import { Folio } from "src/app/models/folio.model";
import { TareasService } from "src/app/services/tareas.service";
import Swal from "sweetalert2";
import { ActivatedRoute } from "@angular/router";
import { TareaOTState } from "src/app/store/reducers";
import { CausaFalla } from '../../../models/causa-falla.model';
import { MetodoDeteccion } from '../../../models/metodo-deteccion.model';
import { TipoFalla } from '../../../models/tipo-falla.model';

@Component({
  selector: "app-detalle-ot",
  templateUrl: "./detalle-ot.component.html",
  styleUrls: ["./detalle-ot.component.scss"],
})
export class DetalleOtComponent implements OnInit, OnDestroy {
  private stop$ = new Subject<void>();
  public tarea: TareaOT;
  public folio: Folio;

  //Tipo de Servicio
  tipoServicio = [
    { value: "Servicio de Emergencia", viewValue: "Servicio de Emergencia" },
    {
      value: "Mantenimiento Preventivo",
      viewValue: "Mantenimiento Preventivo",
    },
    { value: "Trabajo Programado", viewValue: "Trabajo Programado" },
    { value: "Revisión De Equipos", viewValue: "Revisión De Equipos" },
  ];

  tipoPrioridadSeleccionado: string;
  tipoPrioridad = [
    { value: "Muy Alta", viewValue: "Muy Alta" },
    { value: "Alta", viewValue: "Alta" },
    { value: "Media", viewValue: "Media" },
  ];

  cliente: string;
  clientes: Cliente[] = [];

  local: string;
  locales: Local[] = [];

  reponsable: string;
  responsables: Usuario[] = [];

  equipo: string;
  equipos: Equipo[] = [];

  tipoFallas: TipoFalla[] = [];
  causaFallas: CausaFalla[] = [];
  metodosDeteccion: MetodoDeteccion[] = [];

  public tieneFolioLaOT: boolean = false;

  filteredOptions: Observable<Equipo[]>;

  public date: moment.Moment;
  public disabled = false;
  public showSpinners = true;
  public showSeconds = false;
  public touchUi = false;
  public enableMeridian = false;
  public minDate: moment.Moment;
  public maxDate: moment.Moment;
  public stepHour = 1;
  public stepMinute = 1;
  public stepSecond = 1;
  public hideTime: boolean = false;
  public color: ThemePalette = "primary";
  public disableMinute: boolean = false;
  public step = 0;

  public formTimerOT: FormGroup;
  public formTareaOT: FormGroup;
  public formFirmasOT: FormGroup;
  public formChechListGeneral: FormGroup;
  public latitud: number;
  public longitud: number;
  public altitud: number;
  public puedeVerMapa: boolean = true;
  public now: Date;
  public cargando: boolean = false;
  public ejecutaHora: boolean = false;
  public idURL: string;
  constructor(
    private fb: FormBuilder,
    private store: Store<AppState>,
    private authService: AuthService,
    private route: ActivatedRoute
  ) {

    this.formTimerOT = this.fb.group({
      numero: [{ value: "", disabled: true }],
      fecha: [{ value: new Date(), disabled: true }],
      horaInicio: [{ value: "", disabled: true }],
      horaTermino: [{ value: "", disabled: true }],
      tiempoEjecucion: [{ value: "", disabled: true }],      
    });

    this.formTareaOT = this.fb.group({    
      cliente: ["", Validators.required],
      local: ["", Validators.required],
      fechaSolicitudServicio: ["", Validators.required],
      equipo: ["", Validators.required],
      servicio: ["", Validators.required],
      prioridad: [""],
      autor: [{ value: this.authService.user?.name, disabled: true }],
      tecnico: [""],
      antecedentes: ["", Validators.required]
    });

    this.formFirmasOT = this.fb.group({
      foto1: [""],
      foto2: [""],
      foto3: [""],
      foto4: [""],
      foto5: [""],
      observaciones: [""],
      aceptado_por_nombre: [""],
      aceptado_por_rut: [""],
      aceptado_por_cargo: [""],
      aceptado_por_firma: [""],
      revisado_por_nombre: [""],
      revisado_por_rut: [""],
      revisado_por_cargo: [""],
      revisado_por_firma: [""],
      ejecutado_por_nombre: [""],
      ejecutado_por_rut: [""],
      ejecutado_por_cargo: [""],
      ejecutado_por_firma: [""],
    });

    this.formChechListGeneral = this.fb.group({
      latitud: [""],
      longitud: [""],
      altitud: [""],
      descripcion: [""],
      materiales: [""],
      tipoFalla: [""],
      causaFalla: [""],
      metodoDeteccionFalla: [""],
      equipoDetenido: [""],
      motivoDetencion: [""],
    });

    this.store.dispatch(actions.cargarClientes());
    this.store.dispatch(actions.cargarTipoFalla());
    this.store.dispatch(actions.cargarCausaFalla());
    this.store.dispatch(actions.cargarMetodoDeteccion());
    this.store.dispatch(actions.cargarFolio({id: 'tareas_ot'}));
  }

  ngOnInit(): void {

    this.route.params.forEach(param =>
      this.idURL = param['id']
    );

    if(this.idURL && this.idURL.length > 2){
      this.store.dispatch( actions.cargarTareaOT({id: this.idURL}));

      this.store.pipe(select('tarea'), take(2), skip(1)).subscribe(
        (state) => {
        console.log('State recibido de tarea take 2: ', state);
        if(state.loaded) {
          if(state.tareaOT){
             this.cargarTarea(state);
          }                        
        } else {
          Swal.fire('Error', state.error?.error , 'error');
        }
      });
    }

    // Activamos Subscripciones.
    this.subscribirseAlStore();

    // Cargamos Maps
    this.cargarMaps();    
  }

  /**
   * Carga una tarea en todos los formularios existentes, en caso que corresponda el dato.
   * @param state Objeto de tipo TareaOT
   */
  private cargarTarea(state: TareaOTState) {
    if(state && state.tareaOT){
      this.formTimerOT.get('numero').setValue(state.tareaOT.wo_folio.toString());
      this.formTimerOT.get('fecha').setValue(state.tareaOT.creation_date.toString());
    }
  }

  private _filter(value: any): Equipo[] {
    const filterValue = value.toLowerCase();
    return this.equipos.filter((e: Equipo) =>
      e.equipo.toLowerCase().includes(filterValue)
    );
  }

  setStep(index: number) {
    this.step = index;
    if (index === 1) {
      console.log("Verificar permisos MAPS");
    }
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }

  ngOnDestroy(): void {
    stop();
  }

  stop() {
    this.stop$.next();
    this.stop$.complete();
  }

  get servicio(): string {
    return this.formTareaOT.get("servicio").value;
  }

  /**
   * Método que reune todas las subscripciones al Store de NgRx.
   */
  private subscribirseAlStore(): void {
    // Nos subscribimos a los equipos y locales.
    this.store
      .select("clientes")
      .pipe(filter((state) => state.clientes != null))
      .subscribe((state) => {
        this.clientes = state.clientes;
      });

    this.store
      .select("equipos")
      .subscribe((state) => (this.equipos = state.equipos));

    this.store
      .select("locales")
      .pipe(filter((state) => state.locales != null))
      .subscribe((state) => {
        this.locales = state.locales;
      });

    this.store
      .select("usuarios")
      .pipe(filter((state) => state.usuarios != null))
      .subscribe((state) => {
        this.responsables = state.usuarios;
      });

    this.store.select("folio")
    .pipe( filter( (state) => state.folio != null))
    .subscribe( (state) => {
        this.folio = state.folio;
    });

    this.store.select("tipoFallas")
    .pipe( filter( (state) => state.tipoFallas != null))
    .subscribe( (state) => {
        this.tipoFallas = state.tipoFallas;
    });

    this.store.select("causaFallas")
    .pipe( filter( (state) => state.causaFallas != null))
    .subscribe( (state) => {
        this.causaFallas = state.causaFallas;
    });

    this.store.select("metodosDeteccion")
    .pipe( filter( (state) => state.metodosDeteccion != null))
    .subscribe( (state) => {
        this.metodosDeteccion = state.metodosDeteccion;
    });

    this.store.select('ui')
      .subscribe( ({ isLoading }) => this.cargando = isLoading );
      
    this.filteredOptions = this.formTareaOT.get("equipo").valueChanges.pipe(
      startWith(""),
      map((value) => this._filter(value || ""))
    );


  }

  /**
   * Permite cargar el mapa de Google Maps, verifica permisos previamente.
   */
  public cargarMaps() {
    Notification.requestPermission(function (result) {
      if (result === "denied") {
        console.log("Permission wasn't granted. Allow a retry.");
        return;
      } else if (result === "default") {
        console.log("The permission request was dismissed.");
        return;
      }
      console.log("Permission was granted for notifications");
    });

    this.verificarPermisosGeolocalizacion();

    this.obtenerCoordenadas();
  }

  /**
   * Check for Geolocation API permissions
   */
  public verificarPermisosGeolocalizacion(): void {
    navigator.permissions
      .query({ name: "geolocation" })
      .then(function (permissionStatus) {
        console.log("geolocation permission state is ", permissionStatus.state);

        obtenerCoordenadasJavascript();

        permissionStatus.onchange = function () {
          console.log(
            "geolocation permission state has changed to ",
            this.state
          );
        };
      });
  }

  public obtenerCoordenadas(): void {
    navigator.geolocation.getCurrentPosition(function (position) {
      console.log("Geolocation permissions granted");
      console.log("Latitude:" + position.coords.latitude);
      console.log("Longitude:" + position.coords.longitude);

      this.latitud = position.coords.latitude;
      this.longitud = position.coords.longitude;
      this.altitud = position.coords.altitude;

      this.formChechListGeneral
        .get("latitud")
        ?.setValue(position.coords.latitude);
      this.formChechListGeneral
        .get("longitud")
        ?.setValue(position.coords.longitude);
      this.formChechListGeneral
        .get("altitud")
        ?.setValue(position.coords.altitude);
    });
  }

  // Propiedades para componente ngx-mat-combobox
  // URL: https://ngx-mat-combobox.web.app/
  fillInput: boolean = true;
  autocompleteMinChars: number = 0;
  autocompleteDebounceInterval: number = 400;
  get placeholder() {
    const c = this.autocompleteMinChars;
    if (c > 0) {
      return `Escriba al menos ${c} caracteres${c > 1 ? "s" : ""}...`;
    }
    return "Buscar...";
  }
  public filterOptionsFn(campo: string): NgxMatComboboxFilterOptionsFn {
    return (query: string, options: any[]): Observable<any[]> | any[] => {
      return options
        .filter((o) =>
          ("" + o[campo]).toLowerCase().includes(query?.toLowerCase())
        )
        .slice();
    };
  }

  // --------------------------- ngx-mat-combobox

  // Cargamos equipos y locales del cliente seleccionado
  deshabilitarLocalesyEquipos: boolean = true;

  selectCliente(event$: any) {
    if (event$) {
      let cliente: Cliente = event$.value;
      this.store.dispatch(actions.cargarEquipos({ uid: cliente.uid }));
      this.store.dispatch(actions.cargarLocales({ uid: cliente.uid }));
      this.deshabilitarLocalesyEquipos = false;
    }
  }

  // Type con firma de dos parámetros y retorno de un tipo (funciones callbacks)
  // URL: https://www.tutorialesprogramacionya.com/angularya/detalleconcepto.php?punto=24&codigo=24&inicio=20#:~:text=Funciones%20an%C3%B3nimas.,valor1%20%2B%20valor2%3B%20%7D%20console.
  public onFilterOptionsFn: NgxMatComboboxFilterOptionsFn = (
    query: string,
    options: any[]
  ): Observable<any[]> | any[] => {
    //     return of(options.filter(o => ('' + this.readOptionLabel(o)).toLowerCase().startsWith(query)).slice());
    return options
      .filter((o) =>
        ("" + o["nombre"]).toLowerCase().includes(query?.toLowerCase())
      )
      .slice();
  };

  horaIniciada: boolean = false;
  tiempoPausado: boolean = false;
  stopTimer$: Subject<void>;
  stopHoraFinal$: Subject<void>;
  horaInicial: string = "";
  horaFinal: string = "";
  /**
   * Establece la hora de inicio de una OT.
   */
  iniciarOT(): void {
    this.stopTimer$ = new Subject<void>();
    this.stopHoraFinal$ = new Subject<void>();
    this.horaIniciada = true;
    var time = new Date();
    this.horaInicial = time.toLocaleTimeString();
    this.formTareaOT.get("horaInicio").setValue(time.toISOString());
    const number$ = interval(1000).pipe(
      map(() => {
        this.cronometro();        
      })
    );

    const numberTimer$ = interval(1000).pipe(
      map(() => {
        this.tiempo();        
      })
    );

    number$.pipe(takeUntil(this.stopTimer$)).subscribe();
    numberTimer$.pipe(takeUntil(this.stopTimer$)).subscribe();
  }

  pausarOT() {
    console.log("presionó Pausar");
    this.tiempoPausado = !this.tiempoPausado;
    if(!this.tiempoPausado){
      this.stopTimer$ = new Subject<void>();
      this.iniciarOT();
    }else{
      this.stopTimer$.next();
    }
  }

  pararOT(){
    this.stopHoraFinal$.next();
    this.stopTimer$.next();
    this.formChechListGeneral.get("equipoDetenido").setValue(
        this.horaFinal
    );
  }

  cronometro() {
    const date = new Date();
    this.horaFinal = date.toLocaleTimeString();
    this.formTareaOT
      .get("horaTermino")
      .setValue(date.toISOString());
  }

  tiempo(){   
    var day1 = new Date(this.formTareaOT.get("horaInicio").value);
    var day2 = new Date(this.formTareaOT.get("horaTermino").value);
    var tiempo = new Date();
    var difference = day1.getTime()-day2.getTime();
    tiempo.setTime(difference);
    this.formTareaOT?.get("tiempoEjecucion")?.setValue(tiempo.toLocaleTimeString());
  }

  /**
   * Guarda el registro en la nube
   */
  public onSubmit(panel: string): void{
    // Se declara objeto a enviar sin instancia
    console.log('Preparando datos para: ', panel);
    switch(panel){
      case 'encabezado':
            if(this.formTareaOT.invalid){ return; }
            // Mostrar loading...
            this.store.dispatch( actions.isLoading() );
            
            // Formulario válido, se procede a generar un nuevo folio
            console.log('invocando generarFolio..');
            this.store.dispatch( actions.generarFolio({id: 'tareas_ot'}));
            
            // Se crea una nueva instancia de TareaOT para enviar a Firebase
            const { cliente, local, fechaSolicitudServicio, equipo, servicio,
                    prioridad, autor, tecnico, antecedentes } = this.formTareaOT.getRawValue();
            
            const { fecha } = this.formTimerOT.getRawValue();
                    
                    this.tarea = {
                      wo_folio                : this.folio.numero.toString(),
                      creation_date           : fecha.toString(),
                      cliente                 : cliente['cliente'],
                      local                   : local['empresa'],
                      items_log_description   : equipo['equipo'],
                      tasks_log_task_type_main: servicio,
                      priorities_description  : prioridad,
                      requested_by            : autor,
                      description             : antecedentes,
                      cal_date_maintenance    : fechaSolicitudServicio.toString(),
                      personnel_description   : tecnico,
                      id_status_work_order    : (tecnico?.length > 0)?'6':'5'    // 6 Asignada, 5 Pendiente.
                    };

                    this.store.dispatch( actions.crearTareaOT({tareaOT: this.tarea}));

                    this.store.pipe(select('tareas'), take(2), skip(1)).subscribe(
                      (state) => {
                      console.log('State recibido de tareas take 2: ', state);
                      if(state.loaded) {
                        Swal.fire('Registro creado', servicio , 'success');
                        if(state.tareaOT){
                           this.formTimerOT.get('numero').setValue(state.tareaOT.wo_folio.toString());
                           this.formTimerOT.get('fecha').setValue(state.tareaOT.creation_date.toString());
                        }                        
                      } else {
                        Swal.fire('Error', state.error?.error , 'error');
                      }
                    });

                                      
                    break;
      case 'antecedentes':
            break;
      case 'fotos':
            break;
      default:
          console.log('sin form especificado en switch.');
    }
      console.log('Pendiente....');
  }

}

// ------------------------------------------ Fuera de Angular, es Javascript puro
function obtenerCoordenadasJavascript() {
  navigator.geolocation.getCurrentPosition(function(position) {
    console.log('Verificando permisos, Obtener Coordenadas desde javascript');
    console.log('latitud: ', position.coords.latitude);
    console.log('longitude: ', position.coords.longitude);
    console.log('altitude: ', position.coords.altitude);
  });
}

