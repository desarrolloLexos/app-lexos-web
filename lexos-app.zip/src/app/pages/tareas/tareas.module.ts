import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMatDatetimePickerModule, NgxMatTimepickerModule } from '@angular-material-components/datetime-picker';

import { AgmCoreModule } from '@agm/core';
import { CommonModule } from '@angular/common';
import { DetalleOtComponent } from './detalle-ot/detalle-ot.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HttpClientModule } from '@angular/common/http';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NgModule } from '@angular/core';
import { NgxPaginationModule } from 'ngx-pagination';
import { PipesModule } from '../../theme/pipes/pipes.module';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { TareasOtComponent } from './tareas-ot/tareas-ot.component';
import { NgxMatComboboxModule } from 'ngx-mat-combobox';

export const routes = [
  { path: '', component: TareasOtComponent, pathMatch: 'full' },
  { path: 'details', component: DetalleOtComponent, data: { breadcrumb: 'details' } }
];

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    NgxPaginationModule,
    SharedModule,
    PipesModule,
    InfiniteScrollModule,
    MatProgressSpinnerModule,
    FlexLayoutModule,
    MatInputModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatComboboxModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyBdShxA_Ay78Ftz1t8yasQbJncdmc_9ToY'
    })
  ],
  declarations: [
    TareasOtComponent,
    DetalleOtComponent
  ],
})
export class TareasModule { }
