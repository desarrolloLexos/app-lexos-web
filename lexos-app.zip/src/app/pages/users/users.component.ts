import * as actions from 'src/app/store/actions';

import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Subscription, filter } from 'rxjs';
import { User, UserContacts, UserProfile, UserSettings, UserSocial, UserWork } from './user.model';

import { AppSettings } from '../../app.settings';
import { AppState } from 'src/app/store/app.reducers';
import { MatDialog } from '@angular/material/dialog';
import { Settings } from '../../app.settings.model';
import { Store } from '@ngrx/store';
import { UserDialogComponent } from './user-dialog/user-dialog.component';
import { UsersService } from './users.service';
import { UsuariosService } from 'src/app/services/usuarios.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [ UsersService ]
})
export class UsersComponent implements OnInit, OnDestroy {
    public userSubs?: Subscription;
    public users: User[];
    public searchText: string;
    public page:any;
    public settings: Settings;
    public showSearch:boolean = false;
    public viewType:string = 'grid';
    constructor(public appSettings:AppSettings,
                public dialog: MatDialog,
                public usersService:UsersService,
                private usuarioService: UsuariosService,
                private store: Store<AppState>){
        this.settings = this.appSettings.settings;
        this.store.dispatch(actions.setPages({page: {showTareasOT: false}}));

    }

    ngOnInit() {
        this.getUsers();
    }

    ngOnDestroy(): void {
      this.userSubs?.unsubscribe();
    }

    public getUsers(): void {
        this.users = null; //for show spinner each time
        this.usersService.getUsers().subscribe(users => this.users = users);
    }
    public addUser(user:User){
        this.usersService.addUser(user).subscribe(user => this.getUsers());
    }
    public updateUser(user:User){
        this.usersService.updateUser(user).subscribe(user => this.getUsers());
    }
    public deleteUser(user:User){
       this.usersService.deleteUser(user.id).subscribe(user => this.getUsers());
    }

    public changeView(viewType){
        this.viewType = viewType;
        this.showSearch = false;
    }

    public onPageChanged(event){
        this.page = event;
        this.getUsers();
        document.getElementById('main').scrollTop = 0;
    }

    public openUserDialog(user){
        let dialogRef = this.dialog.open(UserDialogComponent, {
            data: user
        });
        dialogRef.afterClosed().subscribe(user => {
            if(user){
                (user.id) ? this.updateUser(user) : this.addUser(user);
            }
        });
        this.showSearch = false;
    }

    // public getUsuarios(): void {
    //   this.userSubs = this.store.select('user')
    //   .pipe(
    //     filter(auth => auth.user !== null)  // El pipe filter permite condicionar al subcribe.
    //   )
    //   .subscribe( ({user}) => {
    //     // El método Listener, debe usar onSnapshot para crear un escucha del store.
    //      this.usuarioService.initUsuariosListener();
    //   });
    // }

}
