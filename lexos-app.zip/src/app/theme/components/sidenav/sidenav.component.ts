import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Storage, getDownloadURL, ref } from '@angular/fire/storage';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { AuthService } from 'src/app/services/auth.service';
import { AppSettings } from '../../../app.settings';
import { Settings } from '../../../app.settings.model';
import { MenuService } from '../menu/menu.service';

@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [ MenuService ]
})
export class SidenavComponent implements OnInit {
  public psConfig: PerfectScrollbarConfigInterface = {
    wheelPropagation:true
  };
  public menuItems:Array<any>;
  public settings: Settings;
  public usuario: string;
  public email: string;
  constructor(
    public appSettings:AppSettings, 
    public menuService:MenuService,
    public authService:AuthService,
    private storage: Storage){
      this.settings = this.appSettings.settings; 
      this.usuario = authService.user?.name;
      this.email = authService.user?.email;
      // Cargamos la imagen del usuario
      getDownloadURL(ref(this.storage, authService.user?.path_image))
        .then((url) => {
          // `url` is the download URL for 'images/stars.jpg'          
          const img = document.getElementById("user-image");
          img.setAttribute("src", url);
        })
        .catch((error) => {
          // Handle any errors
        });
  }

  ngOnInit() {
    this.menuItems = this.menuService.getVerticalMenuItems();    
  }

  ngDoCheck(){
    if(this.settings.fixedSidenav){
      if(this.psConfig.wheelPropagation == true){
        this.psConfig.wheelPropagation = false;
      }      
    }
    else{
      if(this.psConfig.wheelPropagation == false){
        this.psConfig.wheelPropagation = true;
      }  
    }
  }

  public closeSubMenus(){
    let menu = document.getElementById("vertical-menu");
    if(menu){
      for (let i = 0; i < menu.children[0].children.length; i++) {
        let child = menu.children[0].children[i];
        if(child){
          if(child.children[0].classList.contains('expanded')){
              child.children[0].classList.remove('expanded');
              child.children[1].classList.remove('show');
          }
        }
      }
    }
  }

}
