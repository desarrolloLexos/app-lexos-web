import { DocumentData, Firestore, QueryDocumentSnapshot, collection, where,
         getDocs, getDoc, limit, orderBy, query, startAfter, updateDoc,  addDoc,
         collectionGroup  } from '@angular/fire/firestore';
import { TareaOT, TareaOTConverter } from '../models/tarea-ot.model';

import { Injectable } from '@angular/core';
import { Unsubscribe } from '@reduxjs/toolkit';
import { AuthService } from './auth.service';

@Injectable({
  providedIn: 'root'
})
export class TareasService {

  unsubscribe!: Unsubscribe;
  lastVisible: QueryDocumentSnapshot<DocumentData>;

  constructor(private firestore: Firestore,
              private authService: AuthService) {
  }


  /**
   * @description: Pagina una consulta.
   * @url: https://firebase.google.com/docs/firestore/query-data/query-cursors?hl=es&authuser=4#paginate_a_query
   */
  async initTareasOTListener() {
    // Query the first page of docs
    // const first = query(collection(this.firestore, "tareas_ot").withConverter(TareaOTConverter),
    //   orderBy("creation_date", 'desc'), limit(50));
  
    const first = query(collectionGroup(this.firestore, "tareas_ot").withConverter(TareaOTConverter),
      orderBy("creation_date", 'desc'), limit(50));

    const documentSnapshots = await getDocs(first);

    // Get the last visible document
    this.lastVisible = documentSnapshots.docs[documentSnapshots.docs.length - 1];

    const tareasOT: TareaOT[] = [];
    documentSnapshots.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      tareasOT.push(doc.data());
    });

    return tareasOT;
  }

  async getNextTareasOT() {
    // Construct a new query starting at this document
    const next = query(collectionGroup(this.firestore, "tareas_ot").withConverter(TareaOTConverter),
      orderBy("creation_date", 'desc'), 
      startAfter(this.lastVisible),
      limit(50));

    const documentSnapshots = await getDocs(next);
    this.lastVisible = documentSnapshots.docs[documentSnapshots.docs.length - 1];

    const tareasOT: TareaOT[] = [];
    documentSnapshots.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      tareasOT.push(doc.data());
    });

    return tareasOT;
  }


/**
 * Método que crea el registro de una tarea dentro de la colección usuarios.
 * Se genera una subcolección de nombre tareas_ot y se autogenera un ID por
 * cada documento creado.
 * @param tarea 
 */
  async crearTareaOT(tarea: TareaOT){
    const userID = this.authService.userID;

    delete tarea.uid;

    // Generamos el documento y obtenemos el ID del documento para guardarlo como propiedad.
    const tareaRef = await addDoc(
      collection(this.firestore, "usuarios", userID, "tareas_ot")
      .withConverter(TareaOTConverter), {
      ...tarea
    });

    // Actualizamos el valor obtenido en el mismo documento generado
    await updateDoc(tareaRef, {
      id: tareaRef.id
    });

    // Retornamos el objeto actualizado.
    return (await getDoc(tareaRef.withConverter(TareaOTConverter)))?.data();
  }

  async getTareaOTById(id: string){
    const q = query(collectionGroup(this.firestore, "tareas_ot").withConverter(TareaOTConverter),
                    where("id", "==", id),
                    orderBy("creation_date", 'desc'), limit(1));

    return (await getDocs(q)).docs.map((o) => o.data())[0];         
  }

}


