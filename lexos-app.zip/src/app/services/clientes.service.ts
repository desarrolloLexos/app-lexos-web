import { Firestore, doc, getDoc, collection, getDocs, query, orderBy } from '@angular/fire/firestore';

import { Cliente, ClienteConverter } from '../models/cliente.model';
import { Injectable } from '@angular/core';
import { Equipo, EquipoConverter } from '../models/equipo.model';
import { Local, LocalConverter } from '../models/local.model';

@Injectable({
  providedIn: 'root'
})
export class ClientesService {

  constructor(private firestore: Firestore) { }

  async getClientesById(uid: string) {
    const docRef = doc(this.firestore, "clientes", uid)
                  .withConverter(ClienteConverter);
    const docSnap = await getDoc(docRef);

    if (docSnap.exists()) {
      console.log("Document data:", docSnap.data());
    } else {
      // doc.data() will be undefined in this case
      console.log("No such document!");
    }
    return docSnap.data();
  }

  async getClientes(){
    const docRef = query(collection(this.firestore, "clientes")
                   .withConverter(ClienteConverter));
    const docSnap = await getDocs(docRef);
    const clientes: Cliente[] = [];
    docSnap.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      clientes.push(doc.data());
    });
    return clientes;
  }

  async getEquiposByClienteID(uid: string){
    const next = query(collection(this.firestore, "clientes", uid, "equipos")
                      .withConverter(EquipoConverter),
                  orderBy("equipo", 'asc'));

    const documentSnapshots = await getDocs(next);

    const equipos: Equipo[] = [];
    documentSnapshots.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      equipos.push(doc.data());
    });

    return equipos;
  }

  async getLocalesByClienteID(uid: string){
    const next = query(collection(this.firestore, "clientes", uid, "locales")
                      .withConverter(LocalConverter),
                  orderBy("nombre", 'asc'));

    const documentSnapshots = await getDocs(next);

    const equipos: Local[] = [];
    documentSnapshots.forEach((doc) => {
      // doc.data() is never undefined for query doc snapshots
      equipos.push(doc.data());
    });

    return equipos;
  }


}
