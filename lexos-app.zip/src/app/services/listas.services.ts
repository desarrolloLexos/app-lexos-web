import { Firestore, doc, getDoc, collection, getDocs, query, orderBy } from '@angular/fire/firestore';

import { Cliente, ClienteConverter } from '../models/cliente.model';
import { Injectable } from '@angular/core';
import { Equipo, EquipoConverter } from '../models/equipo.model';
import { Local, LocalConverter } from '../models/local.model';
import { TipoFallaConverter } from '../models/tipo-falla.model';
import { CausaFallaConverter } from '../models/causa-falla.model';
import { MetodoDeteccionConverter } from '../models/metodo-deteccion.model';

@Injectable({
  providedIn: 'root'
})
export class ListasService {

  constructor(private firestore: Firestore) { }

  async getListaTipoFalla() {
    const docRef = collection(this.firestore, "tipo_falla")
                    .withConverter(TipoFallaConverter);
    const docSnap = await getDocs(docRef);
    return docSnap.docs.map( (o) => o.data());
  }

  async getListaCausaFalla(){
    const docRef = collection(this.firestore, "lista_causas_fallas")
                   .withConverter(CausaFallaConverter);
    const docSnap = await getDocs(docRef);
    return docSnap.docs.map( (o) => o.data());
  }

  async getListaMetodoDeteccion(){
    const docRef = collection(this.firestore, "lista_metodo_deteccion")
                   .withConverter(MetodoDeteccionConverter);
    const docSnap = await getDocs(docRef);
    return docSnap.docs.map( (o) => o.data());
  }


}
