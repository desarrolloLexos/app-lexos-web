export class Pages {
    constructor(
      public showTareasOT: boolean,
    ){}
}
