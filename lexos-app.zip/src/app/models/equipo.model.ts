import { DocumentData, QueryDocumentSnapshot, SnapshotOptions } from "@angular/fire/firestore";

export class Equipo {

  /* Forma corta de crear un modelo en typescript */
  constructor(
    public ceco: string,
    public codigo: string,
    public equipo: string,
  ){}
}

/* Tipo que permite usar desestructuración de objeto en clase Equipo */
export type EquipoType = {
     ceco: string,
     codigo: string,
     equipo: string
}


// Firestore data converter
export const EquipoConverter = {
  toFirestore: (equipo: Equipo) => {
      return {
            "ceco": equipo.ceco,
            "codigo": equipo.codigo,
            "equipo": equipo.equipo 
          };
  },
  fromFirestore: (snapshot: QueryDocumentSnapshot<DocumentData>,
                  options: SnapshotOptions) => {
      const data = snapshot.data(options);
      return new Equipo(
        data['ceco'],
        data['codigo'],
        data['equipo'],
               
        );
  }
};
