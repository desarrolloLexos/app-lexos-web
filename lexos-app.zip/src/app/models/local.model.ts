import { DocumentData, QueryDocumentSnapshot, SnapshotOptions } from "@angular/fire/firestore";

export class Local {

  /* Forma corta de crear un modelo en typescript */
  constructor(
    public ceco: string,
    public empresa: string,
    public nombre: string,
  ){}
}

/* Tipo que permite usar desestructuración de objeto en clase Local */
export type LocalType = {
    ceco: string,
    empresa: string,
    nombre: string,
}


// Firestore data converter
export const LocalConverter = {
  toFirestore: (local: Local) => {
      return {
            "ceco": local.ceco,
            "empresa": local.empresa,
            "nombre": local.nombre 
          };
  },
  fromFirestore: (snapshot: QueryDocumentSnapshot<DocumentData>,
                  options: SnapshotOptions) => {
      const data = snapshot.data(options);
      return new Local(
        data['ceco'],
        data['empresa'],
        data['nombre'],
               
        );
  }
};
